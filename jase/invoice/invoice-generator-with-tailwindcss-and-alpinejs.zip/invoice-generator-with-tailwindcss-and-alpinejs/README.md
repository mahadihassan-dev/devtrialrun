# Invoice Generator with TailwindCSS and AlpineJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/mithicher/pen/XWbxEaK](https://codepen.io/mithicher/pen/XWbxEaK).

Invoice Generator build with TailwindCSS and AlpineJS. 